<?php

namespace App\Http\Controllers;

use App\Models\EventTimeSchedule;
use Illuminate\Http\Request;

class EventTimeScheduleController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\EventTimeSchedule  $eventTimeSchedule
     * @return \Illuminate\Http\Response
     */
    public function show(EventTimeSchedule $eventTimeSchedule)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\EventTimeSchedule  $eventTimeSchedule
     * @return \Illuminate\Http\Response
     */
    public function edit(EventTimeSchedule $eventTimeSchedule)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\EventTimeSchedule  $eventTimeSchedule
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, EventTimeSchedule $eventTimeSchedule)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\EventTimeSchedule  $eventTimeSchedule
     * @return \Illuminate\Http\Response
     */
    public function destroy(EventTimeSchedule $eventTimeSchedule)
    {
        //
    }
}
