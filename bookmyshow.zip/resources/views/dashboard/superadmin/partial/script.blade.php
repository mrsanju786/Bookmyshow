<script src="{{ asset('dashboard/assets/vendors/perfect-scrollbar/perfect-scrollbar.min.js')}}"></script>
<script src="{{ asset('dashboard/assets/js/bootstrap.bundle.min.js') }}"></script>
<script src="{{ asset('dashboard/assets/vendors/simple-datatables/simple-datatables.js') }}"></script>
<script src="{{ asset('dashboard/assets/vendors/apexcharts/apexcharts.js') }}"></script>
<script src="{{ asset('dashboard/assets/js/pages/dashboard.js') }}"></script>
<script src="{{ asset('dashboard/assets/js/main.js') }}"></script>
<script src="https://code.jquery.com/jquery-3.6.1.js" integrity="sha256-3zlB5s2uwoUzrXK3BT7AX3FyvojsraNFxCc2vC/7pNI=" crossorigin="anonymous"></script>
@stack('script')