

<?php $__env->startSection('content'); ?>


<div class="pagetitle">
    <h1>Sub Categories</h1>
    <nav>
      <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="index.html">Home</a></li>
        <li class="breadcrumb-item">Sub Categories</li>
      </ol>
    </nav>
  </div><!-- End Page Title -->


  
    
<?php if(session('success')): ?>
<div class="alert alert-<?php echo e(session('class') ?: 'danger'); ?>">
  <?php echo e(session('message')); ?>

</div>
<?php endif; ?>
<?php if(session('danger')): ?>
<div class="alert alert-<?php echo e(session('class') ?: 'danger'); ?>">
  <?php echo e(session('message')); ?>

</div>
<?php endif; ?>

  <section class="section">
    <div class="row">
      <div class="col-lg-12">

        <div class="card">
          <div class="card-header">
            Sub Categories Listing
              <button class="btn btn-primary btn-xs" style="float: right;">   
                  <a href="<?php echo e(url('subcategory/create')); ?>" class="text-white">Add Sub Category</a>     
              </button>
          </div>
          <div class="card-body">
            <!-- Table with stripped rows -->
            <table class="table table-striped" id="subcategorytbl">
              <thead>
                <tr>
                  <th scope="col">#</th>
                  <th scope="col">Category Name</th>
                  <th scope="col">Sub Category Name</th>
                  <th scope="col">Action</th>
                </tr>
              </thead>
              <tbody>
                  <?php  $no = 1  ?>
                  <?php $__currentLoopData = $subcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      
                  <tr>
                    <td><?php echo e($no++); ?></td>
                    <td><?php echo e($subcategory->category_name); ?></td>
                    <td><?php echo e($subcategory->name); ?></td>
                    <td>
                      <a href="<?php echo e(url('subcategory/'.$subcategory->id.'/edit')); ?>">
                        <i class="bi bi-pencil-square"></i>
                      </a>
                      <a href="<?php echo e(url('subcategory/'.$subcategory->id .'/delete')); ?>" onclick="return   confirm('Are you sure want to delete this recoard!')">
                        <i class="bi bi-trash-fill"></i>
                      </a>
                    </td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

              </tbody>
            </table>
            <!-- End Table with stripped rows -->

          </div>
        </div>

      </div>
    </div>
  </section>
    <?php $__env->startPush('script'); ?>
      <script>
        // Simple Datatable
        let table1 = document.querySelector('#subcategorytbl');
        let dataTable = new simpleDatatables.DataTable(table1);
      </script>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.superadmin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bookmyshow\resources\views/dashboard/superadmin/subcategory/index.blade.php ENDPATH**/ ?>