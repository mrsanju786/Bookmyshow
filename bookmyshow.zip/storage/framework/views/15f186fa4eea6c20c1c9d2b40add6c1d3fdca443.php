<!DOCTYPE html>
<html lang="en">
<?php echo $__env->make('dashboard.superadmin.partial.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<body>
    <div id="app">
        
        <?php echo $__env->make('dashboard.superadmin.partial.sidemenu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div id="main">
            <header class="mb-3">
                <a href="#" class="burger-btn d-block d-xl-none">
                    <i class="bi bi-justify fs-3"></i>
                </a>
            </header>

                

            <?php echo $__env->yieldContent('content'); ?>

            
        <?php echo $__env->make('dashboard.superadmin.partial.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        </div>
    </div>
    <?php echo $__env->make('dashboard.superadmin.partial.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>

</html><?php /**PATH C:\xampp\htdocs\bookmyshow\resources\views/dashboard/superadmin/layouts/app.blade.php ENDPATH**/ ?>